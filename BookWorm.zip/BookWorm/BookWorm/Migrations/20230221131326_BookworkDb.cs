﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BookWorm.Migrations
{
    /// <inheritdoc />
    public partial class BookworkDb : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Authentications",
                columns: table => new
                {
                    AuthenticationId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Authentications", x => x.AuthenticationId);
                });

            migrationBuilder.CreateTable(
                name: "MyShelfs",
                columns: table => new
                {
                    ShelfId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TransactionType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ProductExpiryDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MyShelfs", x => x.ShelfId);
                });

            migrationBuilder.CreateTable(
                name: "ProductAttributes",
                columns: table => new
                {
                    ProductAttributeId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AttributeValue = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductAttributes", x => x.ProductAttributeId);
                });

            migrationBuilder.CreateTable(
                name: "ProductBeneficiaryMasters",
                columns: table => new
                {
                    ProductBeneficiaryId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProductBeneficiaryPercentage = table.Column<float>(type: "real", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductBeneficiaryMasters", x => x.ProductBeneficiaryId);
                });

            migrationBuilder.CreateTable(
                name: "RoyaltyCalculations",
                columns: table => new
                {
                    RoyaltyCalculationId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RoyaltyCalculations", x => x.RoyaltyCalculationId);
                });

            migrationBuilder.CreateTable(
                name: "AttributesMasters",
                columns: table => new
                {
                    AttributeId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AttributeDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ProductAttributeId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AttributesMasters", x => x.AttributeId);
                    table.ForeignKey(
                        name: "FK_AttributesMasters_ProductAttributes_ProductAttributeId",
                        column: x => x.ProductAttributeId,
                        principalTable: "ProductAttributes",
                        principalColumn: "ProductAttributeId");
                });

            migrationBuilder.CreateTable(
                name: "BeneficiaryMasters",
                columns: table => new
                {
                    BeneficiaryId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BeneficiaryName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BeneficiaryEmailId = table.Column<int>(type: "int", nullable: false),
                    BeneficiaryContactNo = table.Column<long>(type: "bigint", nullable: false),
                    BeneficiaryBankName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BeneficiaryBankBranch = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BeneficiaryIFSC = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BeneficiaryAccountNumber = table.Column<long>(type: "bigint", nullable: false),
                    BeneficiaryAccountType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BeneficiaryPAN = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ProductBeneficiaryMasterProductBeneficiaryId = table.Column<int>(type: "int", nullable: true),
                    RoyaltyCalculationId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BeneficiaryMasters", x => x.BeneficiaryId);
                    table.ForeignKey(
                        name: "FK_BeneficiaryMasters_ProductBeneficiaryMasters_ProductBeneficiaryMasterProductBeneficiaryId",
                        column: x => x.ProductBeneficiaryMasterProductBeneficiaryId,
                        principalTable: "ProductBeneficiaryMasters",
                        principalColumn: "ProductBeneficiaryId");
                    table.ForeignKey(
                        name: "FK_BeneficiaryMasters_RoyaltyCalculations_RoyaltyCalculationId",
                        column: x => x.RoyaltyCalculationId,
                        principalTable: "RoyaltyCalculations",
                        principalColumn: "RoyaltyCalculationId");
                });

            migrationBuilder.CreateTable(
                name: "InvoiceDetails",
                columns: table => new
                {
                    InvoiceDetailId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    BasePrice = table.Column<float>(type: "real", nullable: false),
                    TransactionType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RentNumberOfDays = table.Column<int>(type: "int", nullable: true),
                    RoyaltyCalculationId = table.Column<int>(type: "int", nullable: true),
                    RoyaltyCalculationId1 = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_InvoiceDetails", x => x.InvoiceDetailId);
                    table.ForeignKey(
                        name: "FK_InvoiceDetails_RoyaltyCalculations_RoyaltyCalculationId",
                        column: x => x.RoyaltyCalculationId,
                        principalTable: "RoyaltyCalculations",
                        principalColumn: "RoyaltyCalculationId");
                    table.ForeignKey(
                        name: "FK_InvoiceDetails_RoyaltyCalculations_RoyaltyCalculationId1",
                        column: x => x.RoyaltyCalculationId1,
                        principalTable: "RoyaltyCalculations",
                        principalColumn: "RoyaltyCalculationId");
                });

            migrationBuilder.CreateTable(
                name: "Invoices",
                columns: table => new
                {
                    InvoiceId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    InvoiceDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    InvoiceAmount = table.Column<float>(type: "real", nullable: false),
                    InvoiceDetailId = table.Column<int>(type: "int", nullable: true),
                    RoyaltyCalculationId = table.Column<int>(type: "int", nullable: true),
                    RoyaltyCalculationId1 = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Invoices", x => x.InvoiceId);
                    table.ForeignKey(
                        name: "FK_Invoices_InvoiceDetails_InvoiceDetailId",
                        column: x => x.InvoiceDetailId,
                        principalTable: "InvoiceDetails",
                        principalColumn: "InvoiceDetailId");
                    table.ForeignKey(
                        name: "FK_Invoices_RoyaltyCalculations_RoyaltyCalculationId",
                        column: x => x.RoyaltyCalculationId,
                        principalTable: "RoyaltyCalculations",
                        principalColumn: "RoyaltyCalculationId");
                    table.ForeignKey(
                        name: "FK_Invoices_RoyaltyCalculations_RoyaltyCalculationId1",
                        column: x => x.RoyaltyCalculationId1,
                        principalTable: "RoyaltyCalculations",
                        principalColumn: "RoyaltyCalculationId");
                });

            migrationBuilder.CreateTable(
                name: "ProductMasters",
                columns: table => new
                {
                    ProductId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProductName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ProductEnglishName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ProductBasePrice = table.Column<float>(type: "real", nullable: false),
                    ProductSellingPriceCost = table.Column<float>(type: "real", nullable: false),
                    ProductOfferPrice = table.Column<float>(type: "real", nullable: false),
                    ProductOfferPriceExpiryDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ProductDescriptionShort = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ProductDescriptionLong = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ProductISBN = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ProductAuthor = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsRentable = table.Column<bool>(type: "bit", nullable: false),
                    IsLibrary = table.Column<bool>(type: "bit", nullable: false),
                    RentPerDay = table.Column<float>(type: "real", nullable: true),
                    MinRentDays = table.Column<int>(type: "int", nullable: true),
                    InvoiceDetailId = table.Column<int>(type: "int", nullable: true),
                    MyShelfShelfId = table.Column<int>(type: "int", nullable: true),
                    ProductAttributeId = table.Column<int>(type: "int", nullable: true),
                    ProductBeneficiaryMasterProductBeneficiaryId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductMasters", x => x.ProductId);
                    table.ForeignKey(
                        name: "FK_ProductMasters_InvoiceDetails_InvoiceDetailId",
                        column: x => x.InvoiceDetailId,
                        principalTable: "InvoiceDetails",
                        principalColumn: "InvoiceDetailId");
                    table.ForeignKey(
                        name: "FK_ProductMasters_MyShelfs_MyShelfShelfId",
                        column: x => x.MyShelfShelfId,
                        principalTable: "MyShelfs",
                        principalColumn: "ShelfId");
                    table.ForeignKey(
                        name: "FK_ProductMasters_ProductAttributes_ProductAttributeId",
                        column: x => x.ProductAttributeId,
                        principalTable: "ProductAttributes",
                        principalColumn: "ProductAttributeId");
                    table.ForeignKey(
                        name: "FK_ProductMasters_ProductBeneficiaryMasters_ProductBeneficiaryMasterProductBeneficiaryId",
                        column: x => x.ProductBeneficiaryMasterProductBeneficiaryId,
                        principalTable: "ProductBeneficiaryMasters",
                        principalColumn: "ProductBeneficiaryId");
                });

            migrationBuilder.CreateTable(
                name: "CustomerMasters",
                columns: table => new
                {
                    CustomerId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PhoneNumber = table.Column<int>(type: "int", nullable: false),
                    AuthenticationId = table.Column<int>(type: "int", nullable: true),
                    InvoiceId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CustomerMasters", x => x.CustomerId);
                    table.ForeignKey(
                        name: "FK_CustomerMasters_Authentications_AuthenticationId",
                        column: x => x.AuthenticationId,
                        principalTable: "Authentications",
                        principalColumn: "AuthenticationId");
                    table.ForeignKey(
                        name: "FK_CustomerMasters_Invoices_InvoiceId",
                        column: x => x.InvoiceId,
                        principalTable: "Invoices",
                        principalColumn: "InvoiceId");
                });

            migrationBuilder.CreateTable(
                name: "GenreMasters",
                columns: table => new
                {
                    GenreId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    GenreDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ProductMasterProductId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GenreMasters", x => x.GenreId);
                    table.ForeignKey(
                        name: "FK_GenreMasters_ProductMasters_ProductMasterProductId",
                        column: x => x.ProductMasterProductId,
                        principalTable: "ProductMasters",
                        principalColumn: "ProductId");
                });

            migrationBuilder.CreateTable(
                name: "CustomerMasterMyShelf",
                columns: table => new
                {
                    CustomerId = table.Column<int>(type: "int", nullable: false),
                    ShelfId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CustomerMasterMyShelf", x => new { x.CustomerId, x.ShelfId });
                    table.ForeignKey(
                        name: "FK_CustomerMasterMyShelf_CustomerMasters_CustomerId",
                        column: x => x.CustomerId,
                        principalTable: "CustomerMasters",
                        principalColumn: "CustomerId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_CustomerMasterMyShelf_MyShelfs_ShelfId",
                        column: x => x.ShelfId,
                        principalTable: "MyShelfs",
                        principalColumn: "ShelfId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "LanguageMasters",
                columns: table => new
                {
                    LanguageId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    LanguageDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    GenreMasterGenreId = table.Column<int>(type: "int", nullable: true),
                    ProductMasterProductId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LanguageMasters", x => x.LanguageId);
                    table.ForeignKey(
                        name: "FK_LanguageMasters_GenreMasters_GenreMasterGenreId",
                        column: x => x.GenreMasterGenreId,
                        principalTable: "GenreMasters",
                        principalColumn: "GenreId");
                    table.ForeignKey(
                        name: "FK_LanguageMasters_ProductMasters_ProductMasterProductId",
                        column: x => x.ProductMasterProductId,
                        principalTable: "ProductMasters",
                        principalColumn: "ProductId");
                });

            migrationBuilder.CreateTable(
                name: "ProductTypeMasters",
                columns: table => new
                {
                    TypeId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TypeDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LanguageMasterLanguageId = table.Column<int>(type: "int", nullable: true),
                    ProductMasterProductId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductTypeMasters", x => x.TypeId);
                    table.ForeignKey(
                        name: "FK_ProductTypeMasters_LanguageMasters_LanguageMasterLanguageId",
                        column: x => x.LanguageMasterLanguageId,
                        principalTable: "LanguageMasters",
                        principalColumn: "LanguageId");
                    table.ForeignKey(
                        name: "FK_ProductTypeMasters_ProductMasters_ProductMasterProductId",
                        column: x => x.ProductMasterProductId,
                        principalTable: "ProductMasters",
                        principalColumn: "ProductId");
                });

            migrationBuilder.CreateIndex(
                name: "IX_AttributesMasters_ProductAttributeId",
                table: "AttributesMasters",
                column: "ProductAttributeId");

            migrationBuilder.CreateIndex(
                name: "IX_BeneficiaryMasters_ProductBeneficiaryMasterProductBeneficiaryId",
                table: "BeneficiaryMasters",
                column: "ProductBeneficiaryMasterProductBeneficiaryId");

            migrationBuilder.CreateIndex(
                name: "IX_BeneficiaryMasters_RoyaltyCalculationId",
                table: "BeneficiaryMasters",
                column: "RoyaltyCalculationId");

            migrationBuilder.CreateIndex(
                name: "IX_CustomerMasterMyShelf_ShelfId",
                table: "CustomerMasterMyShelf",
                column: "ShelfId");

            migrationBuilder.CreateIndex(
                name: "IX_CustomerMasters_AuthenticationId",
                table: "CustomerMasters",
                column: "AuthenticationId");

            migrationBuilder.CreateIndex(
                name: "IX_CustomerMasters_InvoiceId",
                table: "CustomerMasters",
                column: "InvoiceId");

            migrationBuilder.CreateIndex(
                name: "IX_GenreMasters_ProductMasterProductId",
                table: "GenreMasters",
                column: "ProductMasterProductId");

            migrationBuilder.CreateIndex(
                name: "IX_InvoiceDetails_RoyaltyCalculationId",
                table: "InvoiceDetails",
                column: "RoyaltyCalculationId");

            migrationBuilder.CreateIndex(
                name: "IX_InvoiceDetails_RoyaltyCalculationId1",
                table: "InvoiceDetails",
                column: "RoyaltyCalculationId1");

            migrationBuilder.CreateIndex(
                name: "IX_Invoices_InvoiceDetailId",
                table: "Invoices",
                column: "InvoiceDetailId");

            migrationBuilder.CreateIndex(
                name: "IX_Invoices_RoyaltyCalculationId",
                table: "Invoices",
                column: "RoyaltyCalculationId");

            migrationBuilder.CreateIndex(
                name: "IX_Invoices_RoyaltyCalculationId1",
                table: "Invoices",
                column: "RoyaltyCalculationId1");

            migrationBuilder.CreateIndex(
                name: "IX_LanguageMasters_GenreMasterGenreId",
                table: "LanguageMasters",
                column: "GenreMasterGenreId");

            migrationBuilder.CreateIndex(
                name: "IX_LanguageMasters_ProductMasterProductId",
                table: "LanguageMasters",
                column: "ProductMasterProductId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductMasters_InvoiceDetailId",
                table: "ProductMasters",
                column: "InvoiceDetailId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductMasters_MyShelfShelfId",
                table: "ProductMasters",
                column: "MyShelfShelfId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductMasters_ProductAttributeId",
                table: "ProductMasters",
                column: "ProductAttributeId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductMasters_ProductBeneficiaryMasterProductBeneficiaryId",
                table: "ProductMasters",
                column: "ProductBeneficiaryMasterProductBeneficiaryId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductTypeMasters_LanguageMasterLanguageId",
                table: "ProductTypeMasters",
                column: "LanguageMasterLanguageId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductTypeMasters_ProductMasterProductId",
                table: "ProductTypeMasters",
                column: "ProductMasterProductId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AttributesMasters");

            migrationBuilder.DropTable(
                name: "BeneficiaryMasters");

            migrationBuilder.DropTable(
                name: "CustomerMasterMyShelf");

            migrationBuilder.DropTable(
                name: "ProductTypeMasters");

            migrationBuilder.DropTable(
                name: "CustomerMasters");

            migrationBuilder.DropTable(
                name: "LanguageMasters");

            migrationBuilder.DropTable(
                name: "Authentications");

            migrationBuilder.DropTable(
                name: "Invoices");

            migrationBuilder.DropTable(
                name: "GenreMasters");

            migrationBuilder.DropTable(
                name: "ProductMasters");

            migrationBuilder.DropTable(
                name: "InvoiceDetails");

            migrationBuilder.DropTable(
                name: "MyShelfs");

            migrationBuilder.DropTable(
                name: "ProductAttributes");

            migrationBuilder.DropTable(
                name: "ProductBeneficiaryMasters");

            migrationBuilder.DropTable(
                name: "RoyaltyCalculations");
        }
    }
}

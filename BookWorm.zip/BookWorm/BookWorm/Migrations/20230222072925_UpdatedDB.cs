﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BookWorm.Migrations
{
    /// <inheritdoc />
    public partial class UpdatedDB : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_BeneficiaryMasters_ProductBeneficiaryMasters_ProductBeneficiaryMasterProductBeneficiaryId",
                table: "BeneficiaryMasters");

            migrationBuilder.DropForeignKey(
                name: "FK_CustomerMasters_Authentications_AuthenticationId",
                table: "CustomerMasters");

            migrationBuilder.DropForeignKey(
                name: "FK_CustomerMasters_Invoices_InvoiceId",
                table: "CustomerMasters");

            migrationBuilder.DropForeignKey(
                name: "FK_InvoiceDetails_RoyaltyCalculations_RoyaltyCalculationId",
                table: "InvoiceDetails");

            migrationBuilder.DropForeignKey(
                name: "FK_InvoiceDetails_RoyaltyCalculations_RoyaltyCalculationId1",
                table: "InvoiceDetails");

            migrationBuilder.DropForeignKey(
                name: "FK_Invoices_InvoiceDetails_InvoiceDetailId",
                table: "Invoices");

            migrationBuilder.DropForeignKey(
                name: "FK_Invoices_RoyaltyCalculations_RoyaltyCalculationId1",
                table: "Invoices");

            migrationBuilder.DropForeignKey(
                name: "FK_ProductMasters_ProductAttributes_ProductAttributeId",
                table: "ProductMasters");

            migrationBuilder.DropTable(
                name: "CustomerMasterMyShelf");

            migrationBuilder.DropIndex(
                name: "IX_ProductMasters_ProductAttributeId",
                table: "ProductMasters");

            migrationBuilder.DropIndex(
                name: "IX_Invoices_InvoiceDetailId",
                table: "Invoices");

            migrationBuilder.DropIndex(
                name: "IX_Invoices_RoyaltyCalculationId1",
                table: "Invoices");

            migrationBuilder.DropIndex(
                name: "IX_InvoiceDetails_RoyaltyCalculationId",
                table: "InvoiceDetails");

            migrationBuilder.DropIndex(
                name: "IX_InvoiceDetails_RoyaltyCalculationId1",
                table: "InvoiceDetails");

            migrationBuilder.DropIndex(
                name: "IX_CustomerMasters_AuthenticationId",
                table: "CustomerMasters");

            migrationBuilder.DropIndex(
                name: "IX_CustomerMasters_InvoiceId",
                table: "CustomerMasters");

            migrationBuilder.DropIndex(
                name: "IX_BeneficiaryMasters_ProductBeneficiaryMasterProductBeneficiaryId",
                table: "BeneficiaryMasters");

            migrationBuilder.DropColumn(
                name: "ProductAttributeId",
                table: "ProductMasters");

            migrationBuilder.DropColumn(
                name: "InvoiceDetailId",
                table: "Invoices");

            migrationBuilder.DropColumn(
                name: "RoyaltyCalculationId1",
                table: "Invoices");

            migrationBuilder.DropColumn(
                name: "RoyaltyCalculationId",
                table: "InvoiceDetails");

            migrationBuilder.DropColumn(
                name: "RoyaltyCalculationId1",
                table: "InvoiceDetails");

            migrationBuilder.DropColumn(
                name: "AuthenticationId",
                table: "CustomerMasters");

            migrationBuilder.DropColumn(
                name: "InvoiceId",
                table: "CustomerMasters");

            migrationBuilder.DropColumn(
                name: "ProductBeneficiaryMasterProductBeneficiaryId",
                table: "BeneficiaryMasters");

            migrationBuilder.AddColumn<int>(
                name: "InvoiceId",
                table: "RoyaltyCalculations",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "ProductId",
                table: "RoyaltyCalculations",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Quantity",
                table: "RoyaltyCalculations",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "TransactionType",
                table: "RoyaltyCalculations",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "ProductImagePath",
                table: "ProductMasters",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "BeneficiaryId",
                table: "ProductBeneficiaryMasters",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "BeneficiaryMasterBeneficiaryId",
                table: "ProductBeneficiaryMasters",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "ProductId",
                table: "ProductAttributes",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "CustomerId",
                table: "MyShelfs",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "CustomerId",
                table: "Invoices",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "InvoiceId",
                table: "InvoiceDetails",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "Password",
                table: "CustomerMasters",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "ShelfId",
                table: "CustomerMasters",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "CustomerId",
                table: "Authentications",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_RoyaltyCalculations_InvoiceId",
                table: "RoyaltyCalculations",
                column: "InvoiceId");

            migrationBuilder.CreateIndex(
                name: "IX_RoyaltyCalculations_ProductId",
                table: "RoyaltyCalculations",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductBeneficiaryMasters_BeneficiaryMasterBeneficiaryId",
                table: "ProductBeneficiaryMasters",
                column: "BeneficiaryMasterBeneficiaryId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductAttributes_ProductId",
                table: "ProductAttributes",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_MyShelfs_CustomerId",
                table: "MyShelfs",
                column: "CustomerId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Invoices_CustomerId",
                table: "Invoices",
                column: "CustomerId");

            migrationBuilder.CreateIndex(
                name: "IX_InvoiceDetails_InvoiceId",
                table: "InvoiceDetails",
                column: "InvoiceId");

            migrationBuilder.CreateIndex(
                name: "IX_Authentications_CustomerId",
                table: "Authentications",
                column: "CustomerId");

            migrationBuilder.AddForeignKey(
                name: "FK_Authentications_CustomerMasters_CustomerId",
                table: "Authentications",
                column: "CustomerId",
                principalTable: "CustomerMasters",
                principalColumn: "CustomerId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_InvoiceDetails_Invoices_InvoiceId",
                table: "InvoiceDetails",
                column: "InvoiceId",
                principalTable: "Invoices",
                principalColumn: "InvoiceId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Invoices_CustomerMasters_CustomerId",
                table: "Invoices",
                column: "CustomerId",
                principalTable: "CustomerMasters",
                principalColumn: "CustomerId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_MyShelfs_CustomerMasters_CustomerId",
                table: "MyShelfs",
                column: "CustomerId",
                principalTable: "CustomerMasters",
                principalColumn: "CustomerId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ProductAttributes_ProductMasters_ProductId",
                table: "ProductAttributes",
                column: "ProductId",
                principalTable: "ProductMasters",
                principalColumn: "ProductId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ProductBeneficiaryMasters_BeneficiaryMasters_BeneficiaryMasterBeneficiaryId",
                table: "ProductBeneficiaryMasters",
                column: "BeneficiaryMasterBeneficiaryId",
                principalTable: "BeneficiaryMasters",
                principalColumn: "BeneficiaryId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_RoyaltyCalculations_Invoices_InvoiceId",
                table: "RoyaltyCalculations",
                column: "InvoiceId",
                principalTable: "Invoices",
                principalColumn: "InvoiceId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_RoyaltyCalculations_ProductMasters_ProductId",
                table: "RoyaltyCalculations",
                column: "ProductId",
                principalTable: "ProductMasters",
                principalColumn: "ProductId",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Authentications_CustomerMasters_CustomerId",
                table: "Authentications");

            migrationBuilder.DropForeignKey(
                name: "FK_InvoiceDetails_Invoices_InvoiceId",
                table: "InvoiceDetails");

            migrationBuilder.DropForeignKey(
                name: "FK_Invoices_CustomerMasters_CustomerId",
                table: "Invoices");

            migrationBuilder.DropForeignKey(
                name: "FK_MyShelfs_CustomerMasters_CustomerId",
                table: "MyShelfs");

            migrationBuilder.DropForeignKey(
                name: "FK_ProductAttributes_ProductMasters_ProductId",
                table: "ProductAttributes");

            migrationBuilder.DropForeignKey(
                name: "FK_ProductBeneficiaryMasters_BeneficiaryMasters_BeneficiaryMasterBeneficiaryId",
                table: "ProductBeneficiaryMasters");

            migrationBuilder.DropForeignKey(
                name: "FK_RoyaltyCalculations_Invoices_InvoiceId",
                table: "RoyaltyCalculations");

            migrationBuilder.DropForeignKey(
                name: "FK_RoyaltyCalculations_ProductMasters_ProductId",
                table: "RoyaltyCalculations");

            migrationBuilder.DropIndex(
                name: "IX_RoyaltyCalculations_InvoiceId",
                table: "RoyaltyCalculations");

            migrationBuilder.DropIndex(
                name: "IX_RoyaltyCalculations_ProductId",
                table: "RoyaltyCalculations");

            migrationBuilder.DropIndex(
                name: "IX_ProductBeneficiaryMasters_BeneficiaryMasterBeneficiaryId",
                table: "ProductBeneficiaryMasters");

            migrationBuilder.DropIndex(
                name: "IX_ProductAttributes_ProductId",
                table: "ProductAttributes");

            migrationBuilder.DropIndex(
                name: "IX_MyShelfs_CustomerId",
                table: "MyShelfs");

            migrationBuilder.DropIndex(
                name: "IX_Invoices_CustomerId",
                table: "Invoices");

            migrationBuilder.DropIndex(
                name: "IX_InvoiceDetails_InvoiceId",
                table: "InvoiceDetails");

            migrationBuilder.DropIndex(
                name: "IX_Authentications_CustomerId",
                table: "Authentications");

            migrationBuilder.DropColumn(
                name: "InvoiceId",
                table: "RoyaltyCalculations");

            migrationBuilder.DropColumn(
                name: "ProductId",
                table: "RoyaltyCalculations");

            migrationBuilder.DropColumn(
                name: "Quantity",
                table: "RoyaltyCalculations");

            migrationBuilder.DropColumn(
                name: "TransactionType",
                table: "RoyaltyCalculations");

            migrationBuilder.DropColumn(
                name: "ProductImagePath",
                table: "ProductMasters");

            migrationBuilder.DropColumn(
                name: "BeneficiaryId",
                table: "ProductBeneficiaryMasters");

            migrationBuilder.DropColumn(
                name: "BeneficiaryMasterBeneficiaryId",
                table: "ProductBeneficiaryMasters");

            migrationBuilder.DropColumn(
                name: "ProductId",
                table: "ProductAttributes");

            migrationBuilder.DropColumn(
                name: "CustomerId",
                table: "MyShelfs");

            migrationBuilder.DropColumn(
                name: "CustomerId",
                table: "Invoices");

            migrationBuilder.DropColumn(
                name: "InvoiceId",
                table: "InvoiceDetails");

            migrationBuilder.DropColumn(
                name: "Password",
                table: "CustomerMasters");

            migrationBuilder.DropColumn(
                name: "ShelfId",
                table: "CustomerMasters");

            migrationBuilder.DropColumn(
                name: "CustomerId",
                table: "Authentications");

            migrationBuilder.AddColumn<int>(
                name: "ProductAttributeId",
                table: "ProductMasters",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "InvoiceDetailId",
                table: "Invoices",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "RoyaltyCalculationId1",
                table: "Invoices",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "RoyaltyCalculationId",
                table: "InvoiceDetails",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "RoyaltyCalculationId1",
                table: "InvoiceDetails",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "AuthenticationId",
                table: "CustomerMasters",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "InvoiceId",
                table: "CustomerMasters",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ProductBeneficiaryMasterProductBeneficiaryId",
                table: "BeneficiaryMasters",
                type: "int",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "CustomerMasterMyShelf",
                columns: table => new
                {
                    CustomerId = table.Column<int>(type: "int", nullable: false),
                    ShelfId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CustomerMasterMyShelf", x => new { x.CustomerId, x.ShelfId });
                    table.ForeignKey(
                        name: "FK_CustomerMasterMyShelf_CustomerMasters_CustomerId",
                        column: x => x.CustomerId,
                        principalTable: "CustomerMasters",
                        principalColumn: "CustomerId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_CustomerMasterMyShelf_MyShelfs_ShelfId",
                        column: x => x.ShelfId,
                        principalTable: "MyShelfs",
                        principalColumn: "ShelfId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ProductMasters_ProductAttributeId",
                table: "ProductMasters",
                column: "ProductAttributeId");

            migrationBuilder.CreateIndex(
                name: "IX_Invoices_InvoiceDetailId",
                table: "Invoices",
                column: "InvoiceDetailId");

            migrationBuilder.CreateIndex(
                name: "IX_Invoices_RoyaltyCalculationId1",
                table: "Invoices",
                column: "RoyaltyCalculationId1");

            migrationBuilder.CreateIndex(
                name: "IX_InvoiceDetails_RoyaltyCalculationId",
                table: "InvoiceDetails",
                column: "RoyaltyCalculationId");

            migrationBuilder.CreateIndex(
                name: "IX_InvoiceDetails_RoyaltyCalculationId1",
                table: "InvoiceDetails",
                column: "RoyaltyCalculationId1");

            migrationBuilder.CreateIndex(
                name: "IX_CustomerMasters_AuthenticationId",
                table: "CustomerMasters",
                column: "AuthenticationId");

            migrationBuilder.CreateIndex(
                name: "IX_CustomerMasters_InvoiceId",
                table: "CustomerMasters",
                column: "InvoiceId");

            migrationBuilder.CreateIndex(
                name: "IX_BeneficiaryMasters_ProductBeneficiaryMasterProductBeneficiaryId",
                table: "BeneficiaryMasters",
                column: "ProductBeneficiaryMasterProductBeneficiaryId");

            migrationBuilder.CreateIndex(
                name: "IX_CustomerMasterMyShelf_ShelfId",
                table: "CustomerMasterMyShelf",
                column: "ShelfId");

            migrationBuilder.AddForeignKey(
                name: "FK_BeneficiaryMasters_ProductBeneficiaryMasters_ProductBeneficiaryMasterProductBeneficiaryId",
                table: "BeneficiaryMasters",
                column: "ProductBeneficiaryMasterProductBeneficiaryId",
                principalTable: "ProductBeneficiaryMasters",
                principalColumn: "ProductBeneficiaryId");

            migrationBuilder.AddForeignKey(
                name: "FK_CustomerMasters_Authentications_AuthenticationId",
                table: "CustomerMasters",
                column: "AuthenticationId",
                principalTable: "Authentications",
                principalColumn: "AuthenticationId");

            migrationBuilder.AddForeignKey(
                name: "FK_CustomerMasters_Invoices_InvoiceId",
                table: "CustomerMasters",
                column: "InvoiceId",
                principalTable: "Invoices",
                principalColumn: "InvoiceId");

            migrationBuilder.AddForeignKey(
                name: "FK_InvoiceDetails_RoyaltyCalculations_RoyaltyCalculationId",
                table: "InvoiceDetails",
                column: "RoyaltyCalculationId",
                principalTable: "RoyaltyCalculations",
                principalColumn: "RoyaltyCalculationId");

            migrationBuilder.AddForeignKey(
                name: "FK_InvoiceDetails_RoyaltyCalculations_RoyaltyCalculationId1",
                table: "InvoiceDetails",
                column: "RoyaltyCalculationId1",
                principalTable: "RoyaltyCalculations",
                principalColumn: "RoyaltyCalculationId");

            migrationBuilder.AddForeignKey(
                name: "FK_Invoices_InvoiceDetails_InvoiceDetailId",
                table: "Invoices",
                column: "InvoiceDetailId",
                principalTable: "InvoiceDetails",
                principalColumn: "InvoiceDetailId");

            migrationBuilder.AddForeignKey(
                name: "FK_Invoices_RoyaltyCalculations_RoyaltyCalculationId1",
                table: "Invoices",
                column: "RoyaltyCalculationId1",
                principalTable: "RoyaltyCalculations",
                principalColumn: "RoyaltyCalculationId");

            migrationBuilder.AddForeignKey(
                name: "FK_ProductMasters_ProductAttributes_ProductAttributeId",
                table: "ProductMasters",
                column: "ProductAttributeId",
                principalTable: "ProductAttributes",
                principalColumn: "ProductAttributeId");
        }
    }
}

﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BookWorm.Migrations
{
    /// <inheritdoc />
    public partial class UpdatedDB20 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AttributesMasters_ProductAttributes_ProductAttributeId",
                table: "AttributesMasters");

            migrationBuilder.DropForeignKey(
                name: "FK_BeneficiaryMasters_RoyaltyCalculations_RoyaltyCalculationId",
                table: "BeneficiaryMasters");

            migrationBuilder.DropForeignKey(
                name: "FK_GenreMasters_ProductMasters_ProductMasterProductId",
                table: "GenreMasters");

            migrationBuilder.DropForeignKey(
                name: "FK_Invoices_RoyaltyCalculations_RoyaltyCalculationId",
                table: "Invoices");

            migrationBuilder.DropForeignKey(
                name: "FK_LanguageMasters_GenreMasters_GenreMasterGenreId",
                table: "LanguageMasters");

            migrationBuilder.DropForeignKey(
                name: "FK_LanguageMasters_ProductMasters_ProductMasterProductId",
                table: "LanguageMasters");

            migrationBuilder.DropForeignKey(
                name: "FK_ProductAttributes_ProductMasters_ProductId",
                table: "ProductAttributes");

            migrationBuilder.DropForeignKey(
                name: "FK_ProductBeneficiaryMasters_BeneficiaryMasters_BeneficiaryMasterBeneficiaryId",
                table: "ProductBeneficiaryMasters");

            migrationBuilder.DropForeignKey(
                name: "FK_ProductMasters_InvoiceDetails_InvoiceDetailId",
                table: "ProductMasters");

            migrationBuilder.DropForeignKey(
                name: "FK_ProductMasters_MyShelfs_MyShelfShelfId",
                table: "ProductMasters");

            migrationBuilder.DropForeignKey(
                name: "FK_ProductMasters_ProductBeneficiaryMasters_ProductBeneficiaryMasterProductBeneficiaryId",
                table: "ProductMasters");

            migrationBuilder.DropForeignKey(
                name: "FK_ProductTypeMasters_LanguageMasters_LanguageMasterLanguageId",
                table: "ProductTypeMasters");

            migrationBuilder.DropForeignKey(
                name: "FK_ProductTypeMasters_ProductMasters_ProductMasterProductId",
                table: "ProductTypeMasters");

            migrationBuilder.DropIndex(
                name: "IX_RoyaltyCalculations_InvoiceId",
                table: "RoyaltyCalculations");

            migrationBuilder.DropIndex(
                name: "IX_RoyaltyCalculations_ProductId",
                table: "RoyaltyCalculations");

            migrationBuilder.DropIndex(
                name: "IX_ProductTypeMasters_LanguageMasterLanguageId",
                table: "ProductTypeMasters");

            migrationBuilder.DropIndex(
                name: "IX_ProductTypeMasters_ProductMasterProductId",
                table: "ProductTypeMasters");

            migrationBuilder.DropIndex(
                name: "IX_ProductBeneficiaryMasters_BeneficiaryMasterBeneficiaryId",
                table: "ProductBeneficiaryMasters");

            migrationBuilder.DropIndex(
                name: "IX_ProductAttributes_ProductId",
                table: "ProductAttributes");

            migrationBuilder.DropIndex(
                name: "IX_LanguageMasters_GenreMasterGenreId",
                table: "LanguageMasters");

            migrationBuilder.DropIndex(
                name: "IX_Invoices_CustomerId",
                table: "Invoices");

            migrationBuilder.DropIndex(
                name: "IX_Invoices_RoyaltyCalculationId",
                table: "Invoices");

            migrationBuilder.DropIndex(
                name: "IX_InvoiceDetails_InvoiceId",
                table: "InvoiceDetails");

            migrationBuilder.DropIndex(
                name: "IX_BeneficiaryMasters_RoyaltyCalculationId",
                table: "BeneficiaryMasters");

            migrationBuilder.DropIndex(
                name: "IX_AttributesMasters_ProductAttributeId",
                table: "AttributesMasters");

            migrationBuilder.DropColumn(
                name: "LanguageMasterLanguageId",
                table: "ProductTypeMasters");

            migrationBuilder.DropColumn(
                name: "ProductMasterProductId",
                table: "ProductTypeMasters");

            migrationBuilder.DropColumn(
                name: "GenreMasterGenreId",
                table: "LanguageMasters");

            migrationBuilder.DropColumn(
                name: "RoyaltyCalculationId",
                table: "Invoices");

            migrationBuilder.DropColumn(
                name: "ShelfId",
                table: "CustomerMasters");

            migrationBuilder.DropColumn(
                name: "RoyaltyCalculationId",
                table: "BeneficiaryMasters");

            migrationBuilder.DropColumn(
                name: "ProductAttributeId",
                table: "AttributesMasters");

            migrationBuilder.RenameColumn(
                name: "ProductBeneficiaryMasterProductBeneficiaryId",
                table: "ProductMasters",
                newName: "ProductTypeMasterTypeId");

            migrationBuilder.RenameColumn(
                name: "MyShelfShelfId",
                table: "ProductMasters",
                newName: "LanguageMasterLanguageId");

            migrationBuilder.RenameColumn(
                name: "InvoiceDetailId",
                table: "ProductMasters",
                newName: "GenreMasterGenreId");

            migrationBuilder.RenameIndex(
                name: "IX_ProductMasters_ProductBeneficiaryMasterProductBeneficiaryId",
                table: "ProductMasters",
                newName: "IX_ProductMasters_ProductTypeMasterTypeId");

            migrationBuilder.RenameIndex(
                name: "IX_ProductMasters_MyShelfShelfId",
                table: "ProductMasters",
                newName: "IX_ProductMasters_LanguageMasterLanguageId");

            migrationBuilder.RenameIndex(
                name: "IX_ProductMasters_InvoiceDetailId",
                table: "ProductMasters",
                newName: "IX_ProductMasters_GenreMasterGenreId");

            migrationBuilder.RenameColumn(
                name: "BeneficiaryMasterBeneficiaryId",
                table: "ProductBeneficiaryMasters",
                newName: "ProductId");

            migrationBuilder.RenameColumn(
                name: "ProductMasterProductId",
                table: "LanguageMasters",
                newName: "ProductTypeMasterTypeId");

            migrationBuilder.RenameIndex(
                name: "IX_LanguageMasters_ProductMasterProductId",
                table: "LanguageMasters",
                newName: "IX_LanguageMasters_ProductTypeMasterTypeId");

            migrationBuilder.RenameColumn(
                name: "ProductMasterProductId",
                table: "GenreMasters",
                newName: "LanguageMasterLanguageId");

            migrationBuilder.RenameIndex(
                name: "IX_GenreMasters_ProductMasterProductId",
                table: "GenreMasters",
                newName: "IX_GenreMasters_LanguageMasterLanguageId");

            migrationBuilder.AddColumn<int>(
                name: "BeneficiaryId",
                table: "RoyaltyCalculations",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "BeneficiaryMasterBeneficiaryId",
                table: "RoyaltyCalculations",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "RoyaltyCalculationTransactiondate",
                table: "RoyaltyCalculations",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AlterColumn<string>(
                name: "TypeDescription",
                table: "ProductTypeMasters",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<bool>(
                name: "IsRentable",
                table: "ProductMasters",
                type: "bit",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AlterColumn<bool>(
                name: "IsLibrary",
                table: "ProductMasters",
                type: "bit",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AddColumn<int>(
                name: "GenreId",
                table: "ProductMasters",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "LanguageId",
                table: "ProductMasters",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "TypeId",
                table: "ProductMasters",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "ProductMasterProductId",
                table: "ProductBeneficiaryMasters",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "AttributeId",
                table: "ProductAttributes",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "AttributeMasterAttributeId",
                table: "ProductAttributes",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ProductMasterProductId",
                table: "ProductAttributes",
                type: "int",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "TransactionType",
                table: "MyShelfs",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<int>(
                name: "ProductId",
                table: "MyShelfs",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "ProductMasterProductId",
                table: "MyShelfs",
                type: "int",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "LanguageDescription",
                table: "LanguageMasters",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<int>(
                name: "TypeId",
                table: "LanguageMasters",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AlterColumn<string>(
                name: "TransactionType",
                table: "InvoiceDetails",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<int>(
                name: "ProductId",
                table: "InvoiceDetails",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "ProductMasterProductId",
                table: "InvoiceDetails",
                type: "int",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "GenreDescription",
                table: "GenreMasters",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<int>(
                name: "LanguageId",
                table: "GenreMasters",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AlterColumn<string>(
                name: "AttributeDescription",
                table: "AttributesMasters",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.CreateIndex(
                name: "IX_RoyaltyCalculations_BeneficiaryMasterBeneficiaryId",
                table: "RoyaltyCalculations",
                column: "BeneficiaryMasterBeneficiaryId");

            migrationBuilder.CreateIndex(
                name: "IX_RoyaltyCalculations_InvoiceId",
                table: "RoyaltyCalculations",
                column: "InvoiceId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_RoyaltyCalculations_ProductId",
                table: "RoyaltyCalculations",
                column: "ProductId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ProductBeneficiaryMasters_BeneficiaryId",
                table: "ProductBeneficiaryMasters",
                column: "BeneficiaryId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ProductBeneficiaryMasters_ProductMasterProductId",
                table: "ProductBeneficiaryMasters",
                column: "ProductMasterProductId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductAttributes_AttributeMasterAttributeId",
                table: "ProductAttributes",
                column: "AttributeMasterAttributeId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductAttributes_ProductMasterProductId",
                table: "ProductAttributes",
                column: "ProductMasterProductId");

            migrationBuilder.CreateIndex(
                name: "IX_MyShelfs_ProductMasterProductId",
                table: "MyShelfs",
                column: "ProductMasterProductId");

            migrationBuilder.CreateIndex(
                name: "IX_Invoices_CustomerId",
                table: "Invoices",
                column: "CustomerId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_InvoiceDetails_InvoiceId",
                table: "InvoiceDetails",
                column: "InvoiceId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_InvoiceDetails_ProductMasterProductId",
                table: "InvoiceDetails",
                column: "ProductMasterProductId");

            migrationBuilder.AddForeignKey(
                name: "FK_GenreMasters_LanguageMasters_LanguageMasterLanguageId",
                table: "GenreMasters",
                column: "LanguageMasterLanguageId",
                principalTable: "LanguageMasters",
                principalColumn: "LanguageId");

            migrationBuilder.AddForeignKey(
                name: "FK_InvoiceDetails_ProductMasters_ProductMasterProductId",
                table: "InvoiceDetails",
                column: "ProductMasterProductId",
                principalTable: "ProductMasters",
                principalColumn: "ProductId");

            migrationBuilder.AddForeignKey(
                name: "FK_LanguageMasters_ProductTypeMasters_ProductTypeMasterTypeId",
                table: "LanguageMasters",
                column: "ProductTypeMasterTypeId",
                principalTable: "ProductTypeMasters",
                principalColumn: "TypeId");

            migrationBuilder.AddForeignKey(
                name: "FK_MyShelfs_ProductMasters_ProductMasterProductId",
                table: "MyShelfs",
                column: "ProductMasterProductId",
                principalTable: "ProductMasters",
                principalColumn: "ProductId");

            migrationBuilder.AddForeignKey(
                name: "FK_ProductAttributes_AttributesMasters_AttributeMasterAttributeId",
                table: "ProductAttributes",
                column: "AttributeMasterAttributeId",
                principalTable: "AttributesMasters",
                principalColumn: "AttributeId");

            migrationBuilder.AddForeignKey(
                name: "FK_ProductAttributes_ProductMasters_ProductMasterProductId",
                table: "ProductAttributes",
                column: "ProductMasterProductId",
                principalTable: "ProductMasters",
                principalColumn: "ProductId");

            migrationBuilder.AddForeignKey(
                name: "FK_ProductBeneficiaryMasters_BeneficiaryMasters_BeneficiaryId",
                table: "ProductBeneficiaryMasters",
                column: "BeneficiaryId",
                principalTable: "BeneficiaryMasters",
                principalColumn: "BeneficiaryId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ProductBeneficiaryMasters_ProductMasters_ProductMasterProductId",
                table: "ProductBeneficiaryMasters",
                column: "ProductMasterProductId",
                principalTable: "ProductMasters",
                principalColumn: "ProductId");

            migrationBuilder.AddForeignKey(
                name: "FK_ProductMasters_GenreMasters_GenreMasterGenreId",
                table: "ProductMasters",
                column: "GenreMasterGenreId",
                principalTable: "GenreMasters",
                principalColumn: "GenreId");

            migrationBuilder.AddForeignKey(
                name: "FK_ProductMasters_LanguageMasters_LanguageMasterLanguageId",
                table: "ProductMasters",
                column: "LanguageMasterLanguageId",
                principalTable: "LanguageMasters",
                principalColumn: "LanguageId");

            migrationBuilder.AddForeignKey(
                name: "FK_ProductMasters_ProductTypeMasters_ProductTypeMasterTypeId",
                table: "ProductMasters",
                column: "ProductTypeMasterTypeId",
                principalTable: "ProductTypeMasters",
                principalColumn: "TypeId");

            migrationBuilder.AddForeignKey(
                name: "FK_RoyaltyCalculations_BeneficiaryMasters_BeneficiaryMasterBeneficiaryId",
                table: "RoyaltyCalculations",
                column: "BeneficiaryMasterBeneficiaryId",
                principalTable: "BeneficiaryMasters",
                principalColumn: "BeneficiaryId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_GenreMasters_LanguageMasters_LanguageMasterLanguageId",
                table: "GenreMasters");

            migrationBuilder.DropForeignKey(
                name: "FK_InvoiceDetails_ProductMasters_ProductMasterProductId",
                table: "InvoiceDetails");

            migrationBuilder.DropForeignKey(
                name: "FK_LanguageMasters_ProductTypeMasters_ProductTypeMasterTypeId",
                table: "LanguageMasters");

            migrationBuilder.DropForeignKey(
                name: "FK_MyShelfs_ProductMasters_ProductMasterProductId",
                table: "MyShelfs");

            migrationBuilder.DropForeignKey(
                name: "FK_ProductAttributes_AttributesMasters_AttributeMasterAttributeId",
                table: "ProductAttributes");

            migrationBuilder.DropForeignKey(
                name: "FK_ProductAttributes_ProductMasters_ProductMasterProductId",
                table: "ProductAttributes");

            migrationBuilder.DropForeignKey(
                name: "FK_ProductBeneficiaryMasters_BeneficiaryMasters_BeneficiaryId",
                table: "ProductBeneficiaryMasters");

            migrationBuilder.DropForeignKey(
                name: "FK_ProductBeneficiaryMasters_ProductMasters_ProductMasterProductId",
                table: "ProductBeneficiaryMasters");

            migrationBuilder.DropForeignKey(
                name: "FK_ProductMasters_GenreMasters_GenreMasterGenreId",
                table: "ProductMasters");

            migrationBuilder.DropForeignKey(
                name: "FK_ProductMasters_LanguageMasters_LanguageMasterLanguageId",
                table: "ProductMasters");

            migrationBuilder.DropForeignKey(
                name: "FK_ProductMasters_ProductTypeMasters_ProductTypeMasterTypeId",
                table: "ProductMasters");

            migrationBuilder.DropForeignKey(
                name: "FK_RoyaltyCalculations_BeneficiaryMasters_BeneficiaryMasterBeneficiaryId",
                table: "RoyaltyCalculations");

            migrationBuilder.DropIndex(
                name: "IX_RoyaltyCalculations_BeneficiaryMasterBeneficiaryId",
                table: "RoyaltyCalculations");

            migrationBuilder.DropIndex(
                name: "IX_RoyaltyCalculations_InvoiceId",
                table: "RoyaltyCalculations");

            migrationBuilder.DropIndex(
                name: "IX_RoyaltyCalculations_ProductId",
                table: "RoyaltyCalculations");

            migrationBuilder.DropIndex(
                name: "IX_ProductBeneficiaryMasters_BeneficiaryId",
                table: "ProductBeneficiaryMasters");

            migrationBuilder.DropIndex(
                name: "IX_ProductBeneficiaryMasters_ProductMasterProductId",
                table: "ProductBeneficiaryMasters");

            migrationBuilder.DropIndex(
                name: "IX_ProductAttributes_AttributeMasterAttributeId",
                table: "ProductAttributes");

            migrationBuilder.DropIndex(
                name: "IX_ProductAttributes_ProductMasterProductId",
                table: "ProductAttributes");

            migrationBuilder.DropIndex(
                name: "IX_MyShelfs_ProductMasterProductId",
                table: "MyShelfs");

            migrationBuilder.DropIndex(
                name: "IX_Invoices_CustomerId",
                table: "Invoices");

            migrationBuilder.DropIndex(
                name: "IX_InvoiceDetails_InvoiceId",
                table: "InvoiceDetails");

            migrationBuilder.DropIndex(
                name: "IX_InvoiceDetails_ProductMasterProductId",
                table: "InvoiceDetails");

            migrationBuilder.DropColumn(
                name: "BeneficiaryId",
                table: "RoyaltyCalculations");

            migrationBuilder.DropColumn(
                name: "BeneficiaryMasterBeneficiaryId",
                table: "RoyaltyCalculations");

            migrationBuilder.DropColumn(
                name: "RoyaltyCalculationTransactiondate",
                table: "RoyaltyCalculations");

            migrationBuilder.DropColumn(
                name: "GenreId",
                table: "ProductMasters");

            migrationBuilder.DropColumn(
                name: "LanguageId",
                table: "ProductMasters");

            migrationBuilder.DropColumn(
                name: "TypeId",
                table: "ProductMasters");

            migrationBuilder.DropColumn(
                name: "ProductMasterProductId",
                table: "ProductBeneficiaryMasters");

            migrationBuilder.DropColumn(
                name: "AttributeId",
                table: "ProductAttributes");

            migrationBuilder.DropColumn(
                name: "AttributeMasterAttributeId",
                table: "ProductAttributes");

            migrationBuilder.DropColumn(
                name: "ProductMasterProductId",
                table: "ProductAttributes");

            migrationBuilder.DropColumn(
                name: "ProductId",
                table: "MyShelfs");

            migrationBuilder.DropColumn(
                name: "ProductMasterProductId",
                table: "MyShelfs");

            migrationBuilder.DropColumn(
                name: "TypeId",
                table: "LanguageMasters");

            migrationBuilder.DropColumn(
                name: "ProductId",
                table: "InvoiceDetails");

            migrationBuilder.DropColumn(
                name: "ProductMasterProductId",
                table: "InvoiceDetails");

            migrationBuilder.DropColumn(
                name: "LanguageId",
                table: "GenreMasters");

            migrationBuilder.RenameColumn(
                name: "ProductTypeMasterTypeId",
                table: "ProductMasters",
                newName: "ProductBeneficiaryMasterProductBeneficiaryId");

            migrationBuilder.RenameColumn(
                name: "LanguageMasterLanguageId",
                table: "ProductMasters",
                newName: "MyShelfShelfId");

            migrationBuilder.RenameColumn(
                name: "GenreMasterGenreId",
                table: "ProductMasters",
                newName: "InvoiceDetailId");

            migrationBuilder.RenameIndex(
                name: "IX_ProductMasters_ProductTypeMasterTypeId",
                table: "ProductMasters",
                newName: "IX_ProductMasters_ProductBeneficiaryMasterProductBeneficiaryId");

            migrationBuilder.RenameIndex(
                name: "IX_ProductMasters_LanguageMasterLanguageId",
                table: "ProductMasters",
                newName: "IX_ProductMasters_MyShelfShelfId");

            migrationBuilder.RenameIndex(
                name: "IX_ProductMasters_GenreMasterGenreId",
                table: "ProductMasters",
                newName: "IX_ProductMasters_InvoiceDetailId");

            migrationBuilder.RenameColumn(
                name: "ProductId",
                table: "ProductBeneficiaryMasters",
                newName: "BeneficiaryMasterBeneficiaryId");

            migrationBuilder.RenameColumn(
                name: "ProductTypeMasterTypeId",
                table: "LanguageMasters",
                newName: "ProductMasterProductId");

            migrationBuilder.RenameIndex(
                name: "IX_LanguageMasters_ProductTypeMasterTypeId",
                table: "LanguageMasters",
                newName: "IX_LanguageMasters_ProductMasterProductId");

            migrationBuilder.RenameColumn(
                name: "LanguageMasterLanguageId",
                table: "GenreMasters",
                newName: "ProductMasterProductId");

            migrationBuilder.RenameIndex(
                name: "IX_GenreMasters_LanguageMasterLanguageId",
                table: "GenreMasters",
                newName: "IX_GenreMasters_ProductMasterProductId");

            migrationBuilder.AlterColumn<string>(
                name: "TypeDescription",
                table: "ProductTypeMasters",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AddColumn<int>(
                name: "LanguageMasterLanguageId",
                table: "ProductTypeMasters",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ProductMasterProductId",
                table: "ProductTypeMasters",
                type: "int",
                nullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "IsRentable",
                table: "ProductMasters",
                type: "bit",
                nullable: false,
                defaultValue: false,
                oldClrType: typeof(bool),
                oldType: "bit",
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "IsLibrary",
                table: "ProductMasters",
                type: "bit",
                nullable: false,
                defaultValue: false,
                oldClrType: typeof(bool),
                oldType: "bit",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "TransactionType",
                table: "MyShelfs",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "LanguageDescription",
                table: "LanguageMasters",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AddColumn<int>(
                name: "GenreMasterGenreId",
                table: "LanguageMasters",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "RoyaltyCalculationId",
                table: "Invoices",
                type: "int",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "TransactionType",
                table: "InvoiceDetails",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "GenreDescription",
                table: "GenreMasters",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ShelfId",
                table: "CustomerMasters",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "RoyaltyCalculationId",
                table: "BeneficiaryMasters",
                type: "int",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "AttributeDescription",
                table: "AttributesMasters",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ProductAttributeId",
                table: "AttributesMasters",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_RoyaltyCalculations_InvoiceId",
                table: "RoyaltyCalculations",
                column: "InvoiceId");

            migrationBuilder.CreateIndex(
                name: "IX_RoyaltyCalculations_ProductId",
                table: "RoyaltyCalculations",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductTypeMasters_LanguageMasterLanguageId",
                table: "ProductTypeMasters",
                column: "LanguageMasterLanguageId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductTypeMasters_ProductMasterProductId",
                table: "ProductTypeMasters",
                column: "ProductMasterProductId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductBeneficiaryMasters_BeneficiaryMasterBeneficiaryId",
                table: "ProductBeneficiaryMasters",
                column: "BeneficiaryMasterBeneficiaryId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductAttributes_ProductId",
                table: "ProductAttributes",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_LanguageMasters_GenreMasterGenreId",
                table: "LanguageMasters",
                column: "GenreMasterGenreId");

            migrationBuilder.CreateIndex(
                name: "IX_Invoices_CustomerId",
                table: "Invoices",
                column: "CustomerId");

            migrationBuilder.CreateIndex(
                name: "IX_Invoices_RoyaltyCalculationId",
                table: "Invoices",
                column: "RoyaltyCalculationId");

            migrationBuilder.CreateIndex(
                name: "IX_InvoiceDetails_InvoiceId",
                table: "InvoiceDetails",
                column: "InvoiceId");

            migrationBuilder.CreateIndex(
                name: "IX_BeneficiaryMasters_RoyaltyCalculationId",
                table: "BeneficiaryMasters",
                column: "RoyaltyCalculationId");

            migrationBuilder.CreateIndex(
                name: "IX_AttributesMasters_ProductAttributeId",
                table: "AttributesMasters",
                column: "ProductAttributeId");

            migrationBuilder.AddForeignKey(
                name: "FK_AttributesMasters_ProductAttributes_ProductAttributeId",
                table: "AttributesMasters",
                column: "ProductAttributeId",
                principalTable: "ProductAttributes",
                principalColumn: "ProductAttributeId");

            migrationBuilder.AddForeignKey(
                name: "FK_BeneficiaryMasters_RoyaltyCalculations_RoyaltyCalculationId",
                table: "BeneficiaryMasters",
                column: "RoyaltyCalculationId",
                principalTable: "RoyaltyCalculations",
                principalColumn: "RoyaltyCalculationId");

            migrationBuilder.AddForeignKey(
                name: "FK_GenreMasters_ProductMasters_ProductMasterProductId",
                table: "GenreMasters",
                column: "ProductMasterProductId",
                principalTable: "ProductMasters",
                principalColumn: "ProductId");

            migrationBuilder.AddForeignKey(
                name: "FK_Invoices_RoyaltyCalculations_RoyaltyCalculationId",
                table: "Invoices",
                column: "RoyaltyCalculationId",
                principalTable: "RoyaltyCalculations",
                principalColumn: "RoyaltyCalculationId");

            migrationBuilder.AddForeignKey(
                name: "FK_LanguageMasters_GenreMasters_GenreMasterGenreId",
                table: "LanguageMasters",
                column: "GenreMasterGenreId",
                principalTable: "GenreMasters",
                principalColumn: "GenreId");

            migrationBuilder.AddForeignKey(
                name: "FK_LanguageMasters_ProductMasters_ProductMasterProductId",
                table: "LanguageMasters",
                column: "ProductMasterProductId",
                principalTable: "ProductMasters",
                principalColumn: "ProductId");

            migrationBuilder.AddForeignKey(
                name: "FK_ProductAttributes_ProductMasters_ProductId",
                table: "ProductAttributes",
                column: "ProductId",
                principalTable: "ProductMasters",
                principalColumn: "ProductId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ProductBeneficiaryMasters_BeneficiaryMasters_BeneficiaryMasterBeneficiaryId",
                table: "ProductBeneficiaryMasters",
                column: "BeneficiaryMasterBeneficiaryId",
                principalTable: "BeneficiaryMasters",
                principalColumn: "BeneficiaryId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ProductMasters_InvoiceDetails_InvoiceDetailId",
                table: "ProductMasters",
                column: "InvoiceDetailId",
                principalTable: "InvoiceDetails",
                principalColumn: "InvoiceDetailId");

            migrationBuilder.AddForeignKey(
                name: "FK_ProductMasters_MyShelfs_MyShelfShelfId",
                table: "ProductMasters",
                column: "MyShelfShelfId",
                principalTable: "MyShelfs",
                principalColumn: "ShelfId");

            migrationBuilder.AddForeignKey(
                name: "FK_ProductMasters_ProductBeneficiaryMasters_ProductBeneficiaryMasterProductBeneficiaryId",
                table: "ProductMasters",
                column: "ProductBeneficiaryMasterProductBeneficiaryId",
                principalTable: "ProductBeneficiaryMasters",
                principalColumn: "ProductBeneficiaryId");

            migrationBuilder.AddForeignKey(
                name: "FK_ProductTypeMasters_LanguageMasters_LanguageMasterLanguageId",
                table: "ProductTypeMasters",
                column: "LanguageMasterLanguageId",
                principalTable: "LanguageMasters",
                principalColumn: "LanguageId");

            migrationBuilder.AddForeignKey(
                name: "FK_ProductTypeMasters_ProductMasters_ProductMasterProductId",
                table: "ProductTypeMasters",
                column: "ProductMasterProductId",
                principalTable: "ProductMasters",
                principalColumn: "ProductId");
        }
    }
}
